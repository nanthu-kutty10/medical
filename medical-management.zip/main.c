/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

************************
*******************************************************/
#include <stdio.h>
#include <conio.h>
#include <string.h>
typedef struct{
    int id;
    char name[50];
    char addr[100];
    char ph[15];
}Supplier;
void storeSuppilerData(Supplier s){
    FILE *file=fopen("suppliers.dat","a");
    if(!file){
        printf("Unable to open file!\n");
        return;
    }
    fwrite(&s,sizeof(Supplier),1,file);
    fclose(file);
}
void searchSupplier(int id){
    FILE *file=fopen("suppliers.dat","rb");
    if(!file){
        printf("Unable to open file!\n");
        return;
    }
    Supplier s;
    while(fread(&s,sizeof(Supplier),1,file)){
        if(s.id==id){
            printf("Found: %s,Address:%s,Phone: %s\n",s.name,s.addr,s.ph);
            fclose(file);
            return;
        }
    }
    printf("Supplier not found!\n");
    fclose(file);
}
void editSupplier(int id,Supplier newData){
    FILE *file=fopen("supliers.dat","r+b");
    if(!file){
        printf("Unable to open file!\n");
        return;
    }
    Supplier s;
    while(fread(&s,sizeof(Supplier),1,file)){
        if(s.id==id){
            fseek(file,-sizeof(Supplier),SEEK_CUR);
            fwrite(&newData,sizeof(Supplier),1,file);
            printf("Supplier updated!\n");
            fclose (file);
            return;
        }
    }
    printf("Supplier not found!\n");
    fclose(file);
}
void deleteSupplier(int id){
    FILE *file=fopen("suppliers.dat","rb");
    FILE *temp=fopen("temp.dat","wb");
    if(!file||!temp){
        printf("Unable to open file!\n");
        return;
    }
    Supplier s;
    while(fread(&s,sizeof(Supplier),1,file)){
        if(s.id!=id){
            fwrite(&s,sizeof(Supplier),1,temp);
        }
    }
    fclose(file);
    fclose(temp);
    remove("suppliers.dat");
    rename("temp.dat","suppliers.dat");
    printf("Supplier deleted!\n");
}

int main()
{
    Supplier s1 ={1,"Supplier1","Address1","123456789"};
    storeSuppilerData(s1);
    searchSupplier(1);
    Supplier s2 ={1,"Updated Supplier","New Address","987654321"};
    editSupplier(1,s2);
    searchSupplier(1);
    deleteSupplier(1);
    return 0;
    
}